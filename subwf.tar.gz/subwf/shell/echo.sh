#!/bin/sh

echo "arg=$1"
echo "TZ=${TZ}"
