#! /bin/bash
oozie job -oozie http://localhost:11000/oozie -kill $1
