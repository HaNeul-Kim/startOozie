#! /bin/bash
today=$(date +%Y%m%d)
oozie job -oozie http://localhost:11000/oozie -config workflow.properties -run -Dtoday=${today}
