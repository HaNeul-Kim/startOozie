#! /bin/bash
cat global.properties > merge_bundle.properties
echo 'oozie.bundle.application.path=${basePath}' >> merge_bundle.properties

inputDate=""
if [ $# -gt 0 ] ; then
    inputDate=$1
else
    inputDate=$(date +%Y%m%d)
fi

today=$(date +%Y-%m-%d -d ${inputDate})
cmd="oozie job -oozie http://localhost:11000/oozie -config merge_bundle.properties -run -Dtoday=${today}"
echo ${cmd}
${cmd}
